## Accuracy (typical users)

| model | policy | n | MAE | coverage_95 | interval_width |
|---|---|---|---|---|---|
| matched | adaptive | 5 | 12.74 | 0.98 | 68.0 |
| matched | adaptive | 10 | 10.32 | 0.97 | 53.82 |
| matched | adaptive | 20 | 6.85 | 0.98 | 40.46 |
| matched | adaptive | 40 | 5.39 | 0.99 | 33.17 |
| matched | fixed | 5 | 11.04 | 0.98 | 66.88 |
| matched | fixed | 10 | 10.46 | 0.98 | 54.27 |
| matched | fixed | 20 | 8.61 | 0.99 | 45.7 |
| matched | fixed | 40 | 6.88 | 0.99 | 39.17 |
| matched | random | 5 | 15.06 | 0.98 | 75.97 |
| matched | random | 10 | 11.6 | 0.99 | 63.17 |
| matched | random | 20 | 9.34 | 0.99 | 50.87 |
| matched | random | 40 | 7.22 | 0.99 | 42.83 |
| mismatched | adaptive | 5 | 16.02 | 0.92 | 66.89 |
| mismatched | adaptive | 10 | 13.01 | 0.88 | 53.33 |
| mismatched | adaptive | 20 | 10.04 | 0.89 | 41.37 |
| mismatched | adaptive | 40 | 8.43 | 0.87 | 33.27 |
| mismatched | fixed | 5 | 16.5 | 0.95 | 69.66 |
| mismatched | fixed | 10 | 13.79 | 0.94 | 58.22 |
| mismatched | fixed | 20 | 10.69 | 0.93 | 48.22 |
| mismatched | fixed | 40 | 9.26 | 0.93 | 40.79 |
| mismatched | random | 5 | 19.0 | 0.92 | 75.63 |
| mismatched | random | 10 | 16.81 | 0.91 | 64.49 |
| mismatched | random | 20 | 13.48 | 0.91 | 53.63 |
| mismatched | random | 40 | 11.95 | 0.87 | 46.56 |

## Robustness at 40 exercises

| behaviour | mean_estimate | mean_interval_width |
|---|---|---|
| hint_spammer | 27.0 | 31.0 |
| random | 3.0 | 10.1 |
| slow | 35.2 | 33.3 |
| typical (reference, true=70) | 66.4 | 37.0 |
