import random
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import collab  # noqa: E402
import coach  # noqa: E402
import engine  # noqa: E402
import simulate  # noqa: E402


def _df(levels, corrects, rt=1.0, tlimit=5.0, hint=0):
    return pd.DataFrame(dict(ts=range(len(levels)), level=levels, correct=corrects,
                             rt=rt, tlimit=tlimit, hint=hint))


def test_all_trials_are_valid():
    for d in engine.DIMENSIONS:
        for lvl in range(1, engine.LEVELS + 1):
            for seed in range(60):
                t = engine.make_trial(d, lvl, random.Random(seed))
                assert t["answer"] in t["choices"]
                assert len(set(t["choices"])) == len(t["choices"]) >= 2


def test_evidence_rules():
    assert engine.evidence(False, 1, 5, False) == 0
    assert engine.evidence(True, 1, 5, False) == 1
    assert engine.evidence(True, 9, 5, False) == 0.85
    assert engine.evidence(True, 1, 5, True) == 0.7


def test_estimate_goes_up_and_down():
    good = engine.estimate_history(_df([4] * 20, [1] * 20), "Attention")[-1]
    bad = engine.estimate_history(_df([2] * 20, [0] * 20), "Attention")[-1]
    assert good["mean"] > 70 and bad["mean"] < 30


def test_interval_narrows_with_data():
    h = engine.estimate_history(_df([3] * 30, [1, 0] * 15), "Attention")
    assert (h[-1]["hi"] - h[-1]["lo"]) < (h[2]["hi"] - h[2]["lo"])


def test_next_level_bounds():
    assert engine.next_level(0) == 1 and engine.next_level(100) == engine.LEVELS
    assert engine.next_level(50) in (2, 3)


def test_db_roundtrip_and_deletion(tmp_path, monkeypatch):
    monkeypatch.setattr(engine, "DB", tmp_path / "t.db")
    t = engine.make_trial("Attention", 2)
    engine.log_trial("u", t, True, 1.2, False, changes=1, t_first=0.5, mood=3)
    engine.log_trial("u", t, False, 0.0, False, abandoned=True)
    profile, hist, df = engine.build_twin("u")
    assert profile["Attention"]["n"] == 1  # abandoned trial does not count for the estimate
    b = engine.behaviour(df)
    assert b["abandon_rate"] == 0.5
    engine.delete_user("u")
    assert len(engine.trials_df("u")) == 0


def test_probes_are_consistent_with_profile():
    profile = {d: dict(mean=m, lo=m - 10, hi=m + 10, n=5)
               for d, m in zip(engine.DIMENSIONS, [20, 40, 60, 80, 35])}
    best = max(profile, key=lambda d: profile[d]["mean"])
    flawed_seen = ok_seen = 0
    for s in range(300):
        p = engine.make_probe(profile, random.Random(s))
        if p["kind"] == "rank":
            assert p["flawed"] == (p["dim"] != best)
        else:
            assert p["flawed"] == (abs(p["value"] - round(profile[p["dim"]]["mean"])) >= 20)
        flawed_seen += p["flawed"]
        ok_seen += not p["flawed"]
    assert flawed_seen > 50 and ok_seen > 50


def test_probe_score():
    assert engine.probe_score(True, "flag", True) == 1.0
    assert engine.probe_score(True, "accept", False) == 0.0
    assert engine.probe_score(False, "accept", False) == 0.8


def test_projection():
    h = pd.DataFrame(dict(attempt=range(1, 21), mean=np.linspace(30, 60, 20), lo=20.0, hi=70.0))
    p = engine.project(h)
    assert p is not None and (p.lo <= p["mean"]).all() and (p["mean"] <= p.hi).all()
    assert p.lo.min() >= 0 and p.hi.max() <= 100
    assert (p.hi - p.lo).iloc[-1] > (p.hi - p.lo).iloc[0]  # uncertainty grows with distance
    assert engine.project(h.head(5)) is None


def test_collab_score():
    trials = pd.DataFrame(dict(hint=[0, 0, 1, 0], abandoned=[0, 0, 0, 0]))
    good = collab.score(["Can you explain why that is recommended?", "Make it easier please"], trials)
    cheat = collab.score(["give me the answer", "my email is a@b.com"], trials)
    assert 0 <= good["score"] <= 100
    assert cheat["components"]["responsible"] == 30.0
    probes = pd.DataFrame(dict(score=[1.0, 1.0, 1.0]))
    assert collab.score([], trials, probes)["components"]["verification"] == 100.0


def test_coach_fallback_is_non_clinical(monkeypatch):
    monkeypatch.setattr(coach, "_llm", lambda *a, **k: None)  # force the rule-based coach, whatever the environment
    profile = {d: dict(mean=50.0, lo=20.0, hi=80.0, n=3) for d in engine.DIMENSIONS}
    plan = engine.make_plan(profile, {d: 70.0 for d in engine.DIMENSIONS})
    c = collab.score([], pd.DataFrame(dict(hint=[], abandoned=[])))
    text = coach.reply(profile, plan, c, [], None, None, 1)
    assert not coach.CLINICAL.search(text)
    assert "lighter" in text


def test_simulation_adaptive_learns():
    res = simulate.run(quick=True, seed=1, reps=4)
    s = simulate.summarize(res)["accuracy"]
    a = s[(s.model == "mismatched") & (s.policy == "adaptive")].set_index("n")
    assert a.loc[40, "MAE"] < a.loc[5, "MAE"]


def test_ollama_provider_and_fallback(monkeypatch):
    import io
    import json as _json
    import urllib.request
    monkeypatch.setenv("COACH_PROVIDER", "ollama")

    class Fake(io.BytesIO):
        def __enter__(self):
            return self

        def __exit__(self, *a):
            return False

    monkeypatch.setattr(urllib.request, "urlopen",
                        lambda *a, **k: Fake(_json.dumps({"message": {"content": "Hello from local model"}}).encode()))
    assert coach._llm("sys", [{"role": "user", "content": "hi"}]) == "Hello from local model"

    def boom(*a, **k):
        raise OSError("no server")
    monkeypatch.setattr(urllib.request, "urlopen", boom)
    assert coach._llm("sys", [{"role": "user", "content": "hi"}]) is None  # falls back to rule-based coach


def test_focus_detection():
    profile = {d: dict(mean=50.0, lo=20.0, hi=80.0, n=3) for d in engine.DIMENSIONS}
    assert coach._focus(profile, "Why should I train attention?") == "Attention"
    assert coach._focus(profile, "how is my working memory?") == "Working memory"
    assert coach._focus(profile, "hello") is None
    assert coach._focus(profile, None) is None


def test_llm_answer_is_grounded_with_facts(monkeypatch):
    monkeypatch.setattr(coach, "_llm", lambda *a, **k: "Attention matters for focus.")
    profile = {d: dict(mean=38.9, lo=6.0, hi=68.0, n=6) for d in engine.DIMENSIONS}
    plan = engine.make_plan(profile, {d: 70.0 for d in engine.DIMENSIONS})
    c = collab.score([], pd.DataFrame(dict(hint=[], abandoned=[])))
    text = coach.reply(profile, plan, c, [], "Why should I train attention?")
    assert "Facts: Attention" in text and "39%" in text and "level 2/5" in text and "still uncertain" in text


def test_old_coach_numbers_are_not_sent_back_to_the_llm():
    hist = [{"role": "user", "text": "Why attention?"},
            {"role": "assistant", "text": "Your Attention is 38.9% after 6 trials."},
            {"role": "user", "text": "And now?"}]
    msgs = coach._clean_history(hist, "And now?")
    assert all("38.9" not in m["content"] for m in msgs)
    assert msgs[0]["role"] == "user" and msgs[-1]["content"] == "And now?"


# ------------------------------------------------ v3: support settings and reading practice
def test_settings_roundtrip_and_deletion(tmp_path, monkeypatch):
    monkeypatch.setattr(engine, "DB", tmp_path / "s.db")
    assert engine.get_settings("u") is None
    engine.set_settings("u", 9, "dyslexia", True, False, True, True)
    assert engine.get_settings("u") == dict(age=9, age_band="8-10", profile="dyslexia", fun=True, reading=False,
                                            calm=True, guardian=True, focus=False, severity="mild")
    assert engine.list_profiles() == ["u"]
    engine.log_activity("u", "Feelings", 1, 1, True)
    assert len(engine.get_activities("u")) == 1
    engine.log_reading("u", 101, 1, 1, 0.8, 5, 1)
    assert len(engine.get_reading("u")) == 1
    assert "support_settings" in engine.export_user("u")
    engine.delete_user("u")
    assert engine.get_settings("u") is None and len(engine.get_reading("u")) == 0
    assert len(engine.get_activities("u")) == 0 and engine.list_profiles() == []


def test_age_caps_and_defaults():
    assert engine.max_level("5-7") == 3 and engine.max_level("8-10") == 4 and engine.max_level("18+") == 5
    assert engine.is_minor("14-17") and not engine.is_minor("18+")
    assert engine.default_fun("5-7") and not engine.default_fun("18+")


def test_compare_reading():
    ref = "The cat sat on the mat."
    assert engine.compare_reading(ref, "the cat sat on the mat")["accuracy"] == 1.0   # case/punctuation ignored
    r = engine.compare_reading(ref, "the cot sat on mat")
    assert r["n_words"] == 6 and r["n_wrong"] == 2
    status = {m["word"]: m["status"] for m in r["marks"]}
    assert status["cat"] == "changed" and status["the"] in ("ok", "missing")
    assert engine.compare_reading(ref, "")["accuracy"] == 0.0
    assert "Perfect" in engine.reading_feedback(engine.compare_reading(ref, ref))
    assert "polish" in engine.reading_feedback(r)


def test_reading_texts_and_levels():
    assert set(engine.READING_TEXTS) == {1, 2, 3, 4, 5}
    for lvl in engine.READING_TEXTS:
        tid, text = engine.pick_text(lvl)
        assert tid // 100 == lvl and text
    good = pd.DataFrame(dict(attempt=[1, 1, 1], level=[2, 2, 2], accuracy=[1.0, 0.95, 0.9]))
    bad = pd.DataFrame(dict(attempt=[1, 1], level=[3, 3], accuracy=[0.3, 0.4]))
    assert engine.reading_level(good) == 3 and engine.reading_level(bad) == 2
    assert engine.reading_level(good, cap=2) == 2 and engine.reading_level(None) == 1


def test_coach_never_names_conditions():
    assert coach.CLINICAL.search("This is typical of dyslexia") and coach.CLINICAL.search("autism")


# ------------------------------------------------ v4: declared profile, voice reading, practice questions
def test_profiles_and_defaults(monkeypatch):
    assert engine.age_band_for(5) == "5-7" and engine.age_band_for(9) == "8-10" and engine.age_band_for(30) == "18+"
    d = engine.profile_defaults("dyslexia", 8)
    assert d["reading"] and d["fun"] and not d["calm"]
    a = engine.profile_defaults("autism", 8)
    assert a["calm"] and not a["fun"] and not a["reading"]
    assert engine.profile_defaults("typical", 30) == dict(fun=False, reading=False, calm=False, focus=False)
    h = engine.profile_defaults("adhd", 9)
    assert h["focus"] and h["fun"] and not h["calm"] and not h["reading"]
    assert "Autism" in engine.profile_label("autism")
    monkeypatch.setenv("SAFE_LABELS", "1")
    assert "Autism" not in engine.profile_label("autism") and "Dyslexia" not in engine.profile_label("dyslexia")
    assert "ADHD" not in engine.profile_label("adhd")
    monkeypatch.delenv("SAFE_LABELS")
    assert "ADHD" in engine.profile_label("adhd")


def test_voice_tolerance_and_correction_script():
    ref = "Because the cat sat on the mat."
    strict = engine.compare_reading(ref, "becuse the cat sat on the mat")
    lenient = engine.compare_reading(ref, "becuse the cat sat on the mat", tolerance=0.8)
    assert strict["n_wrong"] == 1 and lenient["n_wrong"] == 0          # near-match accepted for noisy voice
    assert engine.compare_reading(ref, "the cot sat on the mat", 0.8)["n_wrong"] >= 2   # real mistakes still found
    r = engine.compare_reading("The cat sat.", "the cot sat")
    script = engine.correction_script("Sam", "The cat sat.", r["marks"])
    assert "Sam" in script and "The cat sat." in script and "cat, cat" in script


def _valid(it):
    if it.get("multi"):
        assert it["answers"] and set(it["answers"]) <= set(it["choices"]), it
    else:
        assert it["a"] in it["choices"], it
    assert set(it.get("accept", [])) <= set(it["choices"]), it
    assert len(set(it["choices"])) == len(it["choices"]) >= 2, it
    text = it["q"] + it["why"] + "".join(it["choices"]) + "".join(it.get("accept", []))
    assert it["why"] and it["q"] and "{" not in text, it


def test_practice_questions_are_valid():
    import support_content as sc
    seen = set()
    for it in sc.ITEMS:
        assert it["id"] not in seen
        seen.add(it["id"])
    for cat in sc.CATEGORIES:            # every topic has questions at every level, and they are well formed
        for lvl in (1, 2, 3):
            for seed in range(25):
                it = sc.BANK.generate(cat, lvl, random.Random(seed))
                assert it is not None and it["cat"] == cat, (cat, lvl)
                _valid(it)


def test_practice_question_selection():
    import support_content as sc
    assert sc.soc_level(None) == 1
    ok = pd.DataFrame(dict(level=[1, 1, 1], correct=[1, 1, 1], item_id=[1, 2, 3]))
    bad = pd.DataFrame(dict(level=[2, 2, 2], correct=[0, 0, 1], item_id=[5, 6, 7]))
    assert sc.soc_level(ok, cap=3) == 2 and sc.soc_level(ok, cap=1) == 1 and sc.soc_level(bad) == 1
    for seed in range(40):
        it = sc.pick_item(ok, cap=2, category="Routines", rng=random.Random(seed))
        assert it["cat"] == "Routines" and it["level"] <= 2 and it["a"] in it["choices"]


def test_stt_never_raises_and_reports_errors():
    import stt
    text, err = stt.transcribe(b"not audio", model_name="__missing_model__")
    assert text == "" and err   # no crash: the app falls back to typing


# ------------------------------------------------ v5: ADHD profile, writing practice, word games, no repeats
def test_all_banks_generate_valid_questions():
    import focus_content as fc
    import literacy
    import support_content as sc
    for bank in (sc.BANK, fc.BANK, literacy.WORD_BANK):
        for cat in bank.categories:
            for lvl in (1, 2, 3):
                for seed in range(40):
                    it = bank.generate(cat, lvl, random.Random(seed), {"tricky": ["friend", "because"]})
                    assert it is not None, (cat, lvl)
                    _valid(it)


def test_questions_do_not_repeat():
    """30 questions in a row: never the same question twice, and topics rotate in Mix mode."""
    import focus_content as fc
    import literacy
    import support_content as sc
    for pick in (sc.pick_item, fc.pick_item, lambda h, c, rng: literacy.pick_game(h, c, rng=rng)):
        rng = random.Random(7)
        rows = []
        for _ in range(30):
            hist = pd.DataFrame(rows, columns=["item_id", "level", "correct", "category"])
            it = pick(hist, 3, rng=rng) if pick is not sc.pick_item and pick is not fc.pick_item \
                else pick(hist, 3, None, rng)
            rows.append(dict(item_id=it["id"], level=it["level"], correct=1, category=it["category"]
                             if "category" in it else it["cat"]))
        ids = [r["item_id"] for r in rows]
        cats = [r["category"] for r in rows]
        assert len(set(ids)) == len(ids)
        assert all(a != b for a, b in zip(cats, cats[1:]))


def test_names_change_between_questions():
    import support_content as sc
    it = next(i for i in sc.ITEMS if "{A}" in i["q"])
    qs = {sc.BANK._finish(it, random.Random(s))["q"] for s in range(20)}
    assert len(qs) > 5


def test_static_items_come_back_least_recent_first():
    import practice
    items = [practice.item(k, "T", 1, f"q{k}", ["a", "b"], "a", "w") for k in (1, 2, 3)]
    bank = practice.Bank(["T"], items)
    hist = pd.DataFrame(dict(item_id=[2, 3, 1], level=1, correct=[1, 0, 1], category="T"))
    assert bank.pick(hist, 1)["id"] == 2


def test_brain_games_avoid_recent_exercises():
    rng = random.Random(0)
    sigs = []
    for _ in range(20):
        t = engine.make_trial("Processing speed", 3, rng, avoid=sigs)
        assert t["sig"] not in sigs
        sigs.append(t["sig"])


def test_reading_and_writing_texts_do_not_repeat():
    import literacy
    used = []
    for _ in range(len(engine.READING_TEXTS[2])):
        used.append(engine.pick_text(2, used)[0])
    assert len(set(used)) == len(used)
    assert engine.pick_text(2, used)[0] == used[0]            # all read: the oldest one comes back
    used = []
    for _ in range(len(literacy.WRITING_TEXTS[1])):
        used.append(literacy.pick_writing(1, used)[0])
    assert len(set(used)) == len(used)


def test_compare_writing_letters_and_slips():
    import literacy
    r = literacy.compare_writing("The dog is big.", "the bog is bigg")
    assert r["n_words"] == 4 and r["n_wrong"] == 2 and 0 < r["letter_acc"] < 1
    st = {w["word"]: (w["status"], w["slip"]) for w in r["words"]}
    assert st["dog"] == ("spelling", "mirror") and st["big"] == ("spelling", "double")
    assert not r["capital_ok"] and not r["end_ok"]                    # reminded, but no word is wrong because of it
    assert dict(r["words"][1]["letters"]) == {"d": False, "o": True, "g": True}
    ok = literacy.compare_writing("The dog is big.", "The dog is big.")
    assert ok["word_acc"] == 1 and ok["letter_acc"] == 1 and ok["capital_ok"] and ok["end_ok"]
    assert "Every word" in literacy.writing_feedback(ok)
    m = literacy.compare_writing("My friend and I built it.", "My frend and built it with")
    st = {w["word"]: w["status"] for w in m["words"]}
    assert st["friend"] == "spelling" and st["I"] == "missing" and m["extra"] == ["with"]
    assert literacy.slip_type("was", "wsa") == "swap" and literacy.slip_type("cat", "cot") == "vowel"
    assert literacy.slip_type("castle", "casle") == "missing" and literacy.slip_type("cat", "catt") == "double"
    s = literacy.writing_script("Lina", "My friend.", m)
    assert "Lina" in s and "f, r, i, e, n, d" in s


def test_writing_storage_level_and_tricky_words(tmp_path, monkeypatch):
    import literacy
    monkeypatch.setattr(engine, "DB", tmp_path / "w.db")
    r = literacy.compare_writing("My friend is here.", "My frend is hear.")
    engine.log_writing("u", 201, 2, "look", 1, r)
    engine.log_writing("u", 202, 2, "look", 1, literacy.compare_writing("A frog.", "A frog."))
    df = engine.get_writing("u")
    assert len(df) == 2 and literacy.tricky_words(df) == ["friend", "here"]
    assert engine.writing_summary(df)["sentences"] == 2
    good = pd.DataFrame(dict(attempt=[1, 1, 1], level=[2, 2, 2], word_acc=[1.0, 0.95, 0.9]))
    assert literacy.writing_level(good) == 3 and literacy.writing_level(None) == 1
    assert "writing_practice" in engine.export_user("u")
    engine.delete_user("u")
    assert len(engine.get_writing("u")) == 0


def test_misspellings_are_not_the_word_and_tricky_words_are_used():
    import literacy
    for lvl, words in literacy.SPELL_WORDS.items():
        for w in words:
            wrong = literacy.misspellings(w, random.Random(1))
            assert len(wrong) >= 2 and w not in wrong and not set(wrong) & literacy.REAL
    seen = {literacy.pick_game(None, 1, "Spelling", random.Random(s), tricky=["friend"])["a"] for s in range(30)}
    assert "friend" in seen


def test_activity_domains(tmp_path, monkeypatch):
    monkeypatch.setattr(engine, "DB", tmp_path / "d.db")
    engine.log_activity("u", "Feelings", 1, 1, True)
    engine.log_activity("u", "Stop & go", 1_000_123, 2, False, domain="focus")
    assert len(engine.get_activities("u")) == 2 and len(engine.get_activities("u", "focus")) == 1
    assert engine.practice_summary(engine.get_activities("u")) == {"focus": {"Stop & go": 0},
                                                                   "social": {"Feelings": 100}}


def test_coach_focus_mode(monkeypatch):
    monkeypatch.setattr(coach, "_llm", lambda *a, **k: None)
    profile = {d: dict(mean=50.0, lo=20.0, hi=80.0, n=3) for d in engine.DIMENSIONS}
    plan = engine.make_plan(profile, {d: 70.0 for d in engine.DIMENSIONS})
    c = collab.score([], pd.DataFrame(dict(hint=[], abandoned=[])))
    text = coach.reply(profile, plan, c, [], None, None, None, dict(focus=True))
    assert "movement break" in text and not coach.CLINICAL.search(text)


# ------------------------------------------------ v6 games
def test_new_games_are_offered_to_the_right_profiles():
    import focus_content as fc
    import literacy
    import support_content as sc
    games = {"Robot rescue", "Detective", "Pack your school bag", "Emotion detective", "Treasure map",
             "Copy the rhythm"}
    assert games <= set(fc.CATEGORIES)                                        # ADHD: all six
    assert {"Emotion detective", "Mission: pack my bag"} <= set(sc.CATEGORIES)  # autism (mission version)
    assert {"Copy the rhythm", "Treasure map"} <= set(literacy.GAME_CATEGORIES)  # dyslexia


def test_robot_and_detective_have_exactly_one_right_answer():
    import games_content as g
    for seed in range(200):
        for lvl in (1, 2, 3):
            it = g.robot(lvl, random.Random(seed), {})
            grid = it["html"].split("<br>")
            target = it["why"].split(" ")[3]
            assert sum(row.count(target) for row in grid) == int(it["a"])
            d = g.detective(lvl, random.Random(seed), {})
            assert d["a"] in d["choices"] and len(d["choices"]) == {1: 4, 2: 6, 3: 7}[lvl]


def test_treasure_routes_are_checked():
    import games_content as g
    for seed in range(150):
        it = g.treasure(3, random.Random(seed), {})
        if it is None:
            continue
        assert len(it["choices"]) == 3 and it["a"] == it["choices"][0]
    assert g._walk((0, 0), [("right", 2), ("down", 1)], 4) == (1, 2)
    assert g._walk((0, 0), [("left", 1)], 4) is None                # off the map
    assert g._walk((0, 0), [("right", 2)], 4, rocks={(0, 1)}) is None  # through a rock


def test_emotion_detective_accepts_several_feelings():
    import games_content as g
    it = g.emotions(2, random.Random(1), {})
    assert len(it["accept"]) == 2 and it["a"] in it["accept"]
    it3 = g.emotions(3, random.Random(2), {})
    assert len(it3["accept"]) == 2


def test_pause_station_levels_and_html():
    import games_content as g
    assert [g.pause_level(n) for n in (0, 1, 2, 3, 10)] == [1, 2, 2, 3, 3]
    for kind in g.PAUSE_KINDS:
        h = g.pause_html(kind, 20, g.OWN_IDEAS[0])
        assert "Stop when I want" in h and ">20<" in h
    assert '"drum"' in g.rhythm_player_html(["drum", "bell"])


# ------------------------------------------------ v7: puzzle and hidden leaves
def test_puzzle_pieces_are_all_different_and_only_fit_their_place():
    import visual_games as v
    for lvl in (1, 2, 3):
        for seed in range(8):
            pz = v.new_puzzle(lvl, random.Random(seed))
            rows, cols = v.GRIDS[lvl]
            assert len(pz["tiles"]) == rows * cols == len(set(pz["tiles"]))      # no two identical pieces
            assert pz["tray"] != sorted(pz["tray"])                               # pieces are mixed
    pz = v.new_puzzle(1, random.Random(0))
    p = pz["tray"][0]
    v.puzzle_take(pz, p)
    wrong = next(s for s in range(4) if s != p)
    assert v.puzzle_put(pz, wrong) is False and pz["mistakes"] == 1 and wrong not in pz["placed"]
    assert v.puzzle_put(pz, p) is True and pz["placed"][p] == p
    for q in list(pz["tray"]):
        v.puzzle_take(pz, q)
        v.puzzle_put(pz, q)
    assert pz["done"] and v.puzzle_success(pz)


def test_leaves_find_two_and_memory_game():
    import visual_games as v
    for seed in range(30):
        m = v.new_leaves(1, random.Random(seed))
        same = [i for i, c in enumerate(m["cards"]) if m["cards"].count(c) == 2]
        assert len(m["cards"]) == 8 and len(same) == 2                         # exactly one identical pair
        for lvl, n in ((2, 8), (3, 12)):
            mm = v.new_leaves(lvl, random.Random(seed))
            assert len(mm["cards"]) == n and all(mm["cards"].count(c) == 2 for c in mm["cards"])
    m = v.new_leaves(1, random.Random(3))
    a, b = [i for i, c in enumerate(m["cards"]) if m["cards"].count(c) == 2]
    other = next(i for i in range(8) if i not in (a, b))
    assert v.leaves_flip(m, a) is None and v.leaves_flip(m, other) == "nopair" and m["up"] == []
    assert v.leaves_flip(m, a) is None and v.leaves_flip(m, b) == "pair" and m["done"] and v.leaves_success(m)
    mm = v.new_leaves(3, random.Random(5))
    mm["phase"] = "play"
    pos = {}
    for i, c in enumerate(mm["cards"]):
        pos.setdefault(c, []).append(i)
    first, second = list(pos.values())[:2]
    assert v.leaves_flip(mm, first[0]) is None and v.leaves_flip(mm, second[0]) == "nopair"
    assert len(mm["up"]) == 2                               # both stay visible until the next turn
    third = list(pos.values())[2][0]
    v.leaves_flip(mm, third)                                # next turn: the two cards are hidden again
    assert mm["up"] == [third]
    mm["up"] = []
    for i, j in pos.values():
        v.leaves_flip(mm, i)
        v.leaves_flip(mm, j)
    assert mm["done"] and len(mm["matched"]) == 12


def test_leaf_drawings():
    import visual_games as v
    for shape in v.LEAF_SHAPES:
        for color in v.LEAF_COLORS:
            svg = v.leaf_svg(shape, color)
            assert svg.startswith("<svg") and "{" not in svg and v.LEAF_COLORS[color][0] in svg
    assert "?" in v.card_html(1, ("oak", "red"), "down") and "✅" in v.card_html(1, ("oak", "red"), "match")


# ------------------------------------------------ final version: degree, autism & dyslexia documents
def test_degree_rules_and_storage(tmp_path, monkeypatch):
    monkeypatch.setattr(engine, "DB", tmp_path / "d.db")
    assert [engine.SEVERITY_RULES[k]["plan"] for k in engine.SEVERITIES] == [5, 4, 3]
    assert engine.severity_rules("severe", "autism")["q_cap"] == 2
    assert engine.severity_rules("severe", "typical") == engine.SEVERITY_RULES["mild"]   # typical: no degree
    assert engine.profile_defaults("dyslexia", 9, "severe")["calm"]
    engine.set_settings("u", 9, "adhd", True, False, False, True, True, "moderate")
    assert engine.get_settings("u")["severity"] == "moderate"
    engine.set_settings("u", 9, "adhd", True, False, False, True, True, "nonsense")
    assert engine.get_settings("u")["severity"] == "mild"
    engine.kv_set("u", "day_plan", {"cards": ["wake"]})
    assert engine.kv_get("u", "day_plan") == {"cards": ["wake"]} and "saved_choices" in engine.export_user("u")
    engine.delete_user("u")
    assert engine.kv_get("u", "day_plan") is None


def test_document_activities_are_in_the_right_profiles():
    import literacy
    import support_content as sc
    for cat in ("My day in cards", "Change detective", "Conversation bubbles", "Clue puzzle", "Solution box",
                "Mission: pack my bag", "My interests world"):
        assert cat in sc.CATEGORIES
    for cat in ("Sound detective", "Syllable train", "Twin words", "Hidden letters", "Word market", "Meaning hunt",
                "Rhyme maze", "Prefixes & suffixes", "Story in pictures"):
        assert cat in literacy.GAME_CATEGORIES


def test_several_good_answers_and_none_is_shamed():
    import autism_content as au
    it = au.solution_box(3, random.Random(1), {})
    assert len(it["accept"]) >= 3 and "💭 Another idea of my own" in it["accept"]
    it = au.conversation(2, random.Random(1), {})
    assert len(it["accept"]) == 2
    it = au.interests(1, random.Random(1), {"theme": "space"})
    assert set(it["accept"]) == set(it["choices"])            # a favourite is never wrong
    assert all("Teddy" not in x for x in au.NOT_NEEDED)        # a comfort object is never shown as wrong


def test_day_cards_order_is_clear():
    import autism_content as au
    keys = [k for k, _, _ in au.DAY]
    for seed in range(100):
        it = au.day_cards(2, random.Random(seed), {})
        right = [k for k in keys if au.card(k) in it["a"]]
        idx = [keys.index(k) for k in right]
        assert idx == sorted(idx) and min(b - a for a, b in zip(idx, idx[1:])) >= 2


def test_dyslexia_build_data_and_echo():
    import dyslexia_content as dy
    for lvl, words in dy.BUILD.items():
        for emoji, word, parts in words:
            assert "".join(parts) == word and all(p in dy.SOUND_OF for p in parts), word
    for lvl, sents in dy.SENTENCE_CARDS.items():
        assert all(len(c) >= 3 for c in sents)
    h = dy.echo_html("The little dog runs home.")
    assert "w4" in h and "speechSynthesis" in h
    it = dy.hidden_letters(3, random.Random(2), {})
    t = it["q"].split("**")[1]
    assert all(t in w for w in it["answers"]) and all(t not in w for w in it["choices"] if w not in it["answers"])


def test_studio_never_autoplays():
    import autism_content as au
    for k in au.SOUNDS:
        h = au.studio_html("sound", k)
        import re
        assert "onclick=start" in h                                          # only the Play button starts a sound
        assert not re.search(r"(?<![.\w])(?<!function )start\(\)", h)       # no automatic start() call
