"""End-to-end UI tests with Streamlit's AppTest (runs the real app.py in memory)."""
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
os.environ["DISABLE_VOICE"] = "1"   # tests use the typing path; voice needs a microphone and a model

from streamlit.testing.v1 import AppTest  # noqa: E402


def _btn(at, label):
    return next((b for b in at.button if label in b.label), None)


def _by_label(items, label):
    return next(x for x in items if x.label == label)


def _create(tmp_path, monkeypatch, name, age, profile, consent=True, severity=None):
    monkeypatch.chdir(tmp_path)
    at = AppTest.from_file(str(ROOT / "app.py"), default_timeout=60).run()
    assert any("Create the child" in t.value for t in at.title)         # form shown first
    at.text_input(key="child_name").set_value(name).run()
    at.number_input(key="child_age").set_value(age).run()
    at.radio(key="child_profile").set_value(profile).run()
    if severity:
        at.radio(key="child_severity").set_value(severity).run()
    at.checkbox(key="child_consent").set_value(consent).run()
    _btn(at, "Create profile").click().run()
    return at


def _play(at, label):
    _btn(at, label).click().run()
    if _btn(at, "Show the sequence"):
        _btn(at, "Show the sequence").click().run()
    r = _by_label(at.radio, "Your answer")
    r.set_value(r.options[0]).run()
    _btn(at, "Submit").click().run()
    assert not at.exception


def test_form_requires_name_and_consent(tmp_path, monkeypatch):
    at = _create(tmp_path, monkeypatch, "Sam", 8, "typical", consent=False)
    assert any("must agree" in e.value for e in at.error)
    at.checkbox(key="child_consent").set_value(True).run()
    at.text_input(key="child_name").set_value("").run()
    _btn(at, "Create profile").click().run()
    assert any("first name" in e.value for e in at.error)


def test_typical_child_gets_fun_games_and_age_cap(tmp_path, monkeypatch):
    at = _create(tmp_path, monkeypatch, "Sam", 6, "typical")
    assert not at.exception and any("Hi Sam" in m.value for m in at.markdown)
    labels = [t.label for t in at.tabs]
    assert labels[0] == "🎯 Brain games" and "📖 Reading practice" not in labels
    for _ in range(5):
        _play(at, "New game")
    import engine
    df = engine.trials_df("Sam")
    assert len(df) == 5 and df.level.max() <= 3
    assert engine.get_settings("Sam")["profile"] == "typical"


def test_dyslexia_profile_reading_flow(tmp_path, monkeypatch):
    at = _create(tmp_path, monkeypatch, "Lina", 9, "dyslexia")
    labels = [t.label for t in at.tabs]
    assert labels[0] == "📖 Reading practice"                              # main activity first
    _btn(at, "New sentence").click().run()
    _btn(at, "I'm ready").click().run()                                    # typed mode (voice disabled)
    _by_label(at.text_input, "Type the sentence you read").set_value("totally wrong words").run()
    _btn(at, "Check").click().run()
    assert any("polish" in i.value for i in at.info)                       # feedback with words to polish
    assert at.session_state["rd"]["script"].startswith("Good try, Lina")   # voice-agent correction script
    _btn(at, "Try again").click().run()
    text = at.session_state["rd"]["text"]
    _by_label(at.text_input, "Type the sentence again").set_value(text).run()
    _btn(at, "Check").click().run()
    assert not at.exception
    import engine
    df = engine.get_reading("Lina")
    assert list(df.attempt) == [1, 2] and df.accuracy.iloc[1] == 1.0
    assert any("improved" in s.value for s in at.success)


def test_autism_profile_questions_and_break(tmp_path, monkeypatch):
    at = _create(tmp_path, monkeypatch, "Omar", 8, "autism")
    assert [t.label for t in at.tabs][0] == "🌈 Feelings & routines"
    import engine
    s = engine.get_settings("Omar")
    assert s["calm"] and not s["fun"]
    _btn(at, "Next question").click().run()
    item = at.session_state["soc"]
    r = _by_label(at.radio, "Pick one")
    wrong = next(c for c in item["choices"] if c != item["a"])
    r.set_value(wrong).run()
    _btn(at, "Check").click().run()                                        # wrong answer: gentle message
    assert any("Thanks for trying" in i.value for i in at.info) and not at.error
    _btn(at, "I need a break").click().run()
    assert any("Take your time" in i.value for i in at.info)
    assert len(engine.get_activities("Omar")) == 1 and engine.get_activities("Omar").correct.iloc[0] == 0


def test_calm_mode_has_no_time_penalty_and_switching_profiles(tmp_path, monkeypatch):
    at = _create(tmp_path, monkeypatch, "Omar", 8, "autism")
    _play(at, "New exercise")
    import engine
    assert engine.trials_df("Omar").tlimit.iloc[0] == 999.0
    # delete profile -> back to the form
    _btn(at, "Delete this profile").click().run()
    assert engine.get_settings("Omar") is None and any("Create the child" in t.value for t in at.title)


# ------------------------------------------------ v5
def _answer_practice(at, key, right=True):
    """Answer the current practice question of tab `key` (hides the steps first if needed)."""
    if _btn(at, "I've read it"):
        _btn(at, "I've read it").click().run()
    if _btn(at, "I've listened"):
        _btn(at, "I've listened").click().run()
    item = at.session_state[key]
    if item.get("multi"):                                                  # tick boxes (school bag)
        n = at.session_state[f"{key}_n"]
        pick = item["answers"] if right else [next(c for c in item["choices"] if c not in item["answers"])]
        for i, c in enumerate(item["choices"]):
            if c in pick:
                at.checkbox(key=f"{key}_cb_{n}_{i}").check().run()
    else:
        r = next(x for x in at.radio if x.key and x.key.startswith(f"{key}_ans_"))
        wrong = [c for c in item["choices"] if c != item["a"] and c not in item.get("accept", [])]
        r.set_value(item["a"] if right else wrong[0]).run()
    next(b for b in at.button if b.key == f"{key}_check").click().run()
    assert not at.exception
    return item


def test_adhd_profile_focus_rounds_and_movement_break(tmp_path, monkeypatch):
    at = _create(tmp_path, monkeypatch, "Rayan", 9, "adhd")
    labels = [t.label for t in at.tabs]
    assert labels[0] == "⚡ Focus & self-control"
    import engine
    s = engine.get_settings("Rayan")
    assert s["focus"] and s["fun"] and not s["calm"]
    ids = []
    for k in range(5):
        next(b for b in at.button if b.key == "foc_next").click().run()
        ids.append(_answer_practice(at, "foc", right=(k != 2))["id"])
    assert len(set(ids)) == 5                                                # no repeated question
    assert any("Movement break" in x.value for x in at.success)              # round of 5 -> movement break
    assert at.session_state["foc_stars"] == 4
    next(b for b in at.button if b.key == "foc_back").click().run()
    assert not any("Movement break" in x.value for x in at.success)
    df = engine.get_activities("Rayan", "focus")
    assert len(df) == 5 and df.correct.sum() == 4


def test_dyslexia_writing_look_hide_write(tmp_path, monkeypatch):
    at = _create(tmp_path, monkeypatch, "Lina", 9, "dyslexia")
    labels = [t.label for t in at.tabs]
    assert labels[:3] == ["📖 Reading practice", "✍️ Writing practice", "🔤 Word games"]
    next(b for b in at.button if b.key == "wr_new").click().run()
    text = at.session_state["wr"]["text"]
    assert at.session_state["wr"]["phase"] == "look"
    next(b for b in at.button if b.key == "wr_hide").click().run()
    assert not any(text in m.value for m in at.markdown)                    # the sentence is hidden
    words = text.rstrip(".").split()
    wrong = " ".join(w if i else w.lower() for i, w in enumerate(words[:-1])) + " " + words[-1][::-1]
    next(t for t in at.text_area if t.label == "Write the sentence here").set_value(wrong).run()
    next(b for b in at.button if b.key == "wr_check").click().run()
    assert at.session_state["wr"]["phase"] == "feedback"
    assert any("spelling to fix" in m.value for m in at.markdown)          # letter-level correction shown
    assert at.session_state["wr"]["res1"]["n_wrong"] >= 1
    next(b for b in at.button if b.key == "wr_again").click().run()
    next(b for b in at.button if b.key == "wr_hide").click().run()        # look again, then hide again
    next(t for t in at.text_area if t.label == "Write the sentence here").set_value(text).run()
    next(b for b in at.button if b.key == "wr_check").click().run()
    assert not at.exception and any("improved" in x.value for x in at.success)
    import engine
    df = engine.get_writing("Lina")
    assert list(df.attempt) == [1, 2] and df.word_acc.iloc[1] == 1.0


def test_dyslexia_word_games_and_tricky_words(tmp_path, monkeypatch):
    at = _create(tmp_path, monkeypatch, "Lina", 9, "dyslexia")
    for _ in range(4):
        next(b for b in at.button if b.key == "wg_next").click().run()
        _answer_practice(at, "wg")
    import engine
    df = engine.get_activities("Lina", "words")
    assert len(df) == 4 and df.correct.all() and df.item_id.nunique() == 4
    assert df.category.nunique() >= 3                                      # topics rotate in Mix mode


def test_autism_new_topics_and_no_repeat(tmp_path, monkeypatch):
    at = _create(tmp_path, monkeypatch, "Omar", 8, "autism")
    for _ in range(8):
        next(b for b in at.button if b.key == "soc_next").click().run()
        _answer_practice(at, "soc")
    import engine
    df = engine.get_activities("Omar", "social")
    assert df.item_id.nunique() == 8 and df.category.nunique() >= 5
    tab = next(t for t in at.tabs if t.label == "📊 Dashboard")
    assert not at.exception and tab


# ------------------------------------------------ v6: new games and the pause station
def test_adhd_new_games_by_topic(tmp_path, monkeypatch):
    at = _create(tmp_path, monkeypatch, "Rayan", 10, "adhd")
    topics = ["Robot rescue", "Detective", "Pack your school bag", "Emotion detective", "Treasure map",
              "Copy the rhythm"]
    for k, topic in enumerate(topics):
        if at.session_state["foc_move"] if "foc_move" in at.session_state else None:
            next(b for b in at.button if b.key == "foc_back").click().run()
        at.selectbox(key="foc_topic").set_value(topic).run()
        next(b for b in at.button if b.key == "foc_next").click().run()
        it = _answer_practice(at, "foc", right=True)
        assert it["cat"] == topic
    import engine
    df = engine.get_activities("Rayan", "focus")
    assert len(df) == 6 and df.correct.all() and set(df.category) == set(topics)


def test_school_bag_multi_select_feedback(tmp_path, monkeypatch):
    at = _create(tmp_path, monkeypatch, "Omar", 9, "autism")
    import random
    import games_content
    import practice
    item = practice.Bank(["Pack your school bag"], (), {"Pack your school bag": games_content.school_bag}) \
        ._finish(games_content.school_bag(2, random.Random(3), {}), random.Random(3))
    at.session_state["soc"] = item
    at.session_state["soc_n"] = 1
    at.run()
    wrong = next(c for c in item["choices"] if c not in item["answers"])
    at.checkbox(key=f"soc_cb_1_{item['choices'].index(item['answers'][0])}").check().run()
    at.checkbox(key=f"soc_cb_1_{item['choices'].index(wrong)}").check().run()
    next(b for b in at.button if b.key == "soc_check").click().run()
    txt = " ".join(i.value for i in at.info)
    assert "Still to add" in txt and "Not needed" in txt and wrong in txt


def test_pause_station_for_every_profile(tmp_path, monkeypatch):
    at = _create(tmp_path, monkeypatch, "Sam", 8, "typical")
    assert "🚀 Pause station" in [t.label for t in at.tabs]
    next(b for b in at.button if b.key == "ps_start").click().run()
    next(b for b in at.button if b.key == "ps_done").click().run()
    assert any("moment for yourself" in x.value for x in at.success)
    import engine
    assert len(engine.get_activities("Sam", "pause")) == 1


def test_plan_line_shows_red_cross_for_wrong_answers(tmp_path, monkeypatch):
    at = _create(tmp_path, monkeypatch, "Omar", 8, "autism")
    for right in (True, False):
        next(b for b in at.button if b.key == "soc_next").click().run()
        _answer_practice(at, "soc", right=right)
    plan = next(m.value for m in at.markdown if "Today's plan" in m.value)
    assert "✅ 1" in plan and "❌ 2" in plan and "⬜ 3" in plan


# ------------------------------------------------ v7: puzzle & hidden leaves
def test_puzzle_and_leaves_tab_for_autism_adhd_dyslexia(tmp_path, monkeypatch):
    for name, prof in (("Omar", "autism"), ("Rayan", "adhd"), ("Lina", "dyslexia")):
        (tmp_path / prof).mkdir()
        at = _create(tmp_path / prof, monkeypatch, name, 9, prof)
        assert "🧩 Puzzle & leaves" in [t.label for t in at.tabs], prof
    (tmp_path / "typical").mkdir()
    at = _create(tmp_path / "typical", monkeypatch, "Sam", 9, "typical")
    assert "🧩 Puzzle & leaves" not in [t.label for t in at.tabs]


def test_puzzle_played_in_the_app(tmp_path, monkeypatch):
    at = _create(tmp_path, monkeypatch, "Omar", 9, "autism")
    next(b for b in at.button if b.key == "pz_new").click().run()
    pz = at.session_state["pz"]
    first = pz["tray"][0]
    next(b for b in at.button if b.key == f"pz_take_{first}").click().run()
    wrong = next(s for s in range(len(pz["tiles"])) if s != first)
    next(b for b in at.button if b.key == f"pz_put_{wrong}").click().run()
    assert any("somewhere else" in i.value for i in at.info)
    for p in list(at.session_state["pz"]["tray"]):
        next(b for b in at.button if b.key == f"pz_take_{p}").click().run()
        next(b for b in at.button if b.key == f"pz_put_{p}").click().run()
    assert not at.exception and any("finished the puzzle" in x.value for x in at.success)
    import engine
    df = engine.get_activities("Omar", "games")
    assert list(df.category) == ["Puzzle"] and df.correct.iloc[0] == 1


def test_leaves_game_played_in_the_app(tmp_path, monkeypatch):
    at = _create(tmp_path, monkeypatch, "Rayan", 9, "adhd")
    at.radio(key="vg_game").set_value("🍂 Find the same leaves").run()
    next(b for b in at.button if b.key == "lv_new").click().run()
    m = at.session_state["lv"]
    assert m["level"] == 1 and m["phase"] == "find"
    a, b = [i for i, c in enumerate(m["cards"]) if m["cards"].count(c) == 2]
    next(x for x in at.button if x.key == f"lv_{a}").click().run()
    next(x for x in at.button if x.key == f"lv_{b}").click().run()
    assert not at.exception and any("exactly the same" in x.value for x in at.success)
    import engine
    assert list(engine.get_activities("Rayan", "games").category) == ["Leaves"]



# ------------------------------------------------ final version
def _key(at, k):
    return next(b for b in at.button if b.key == k)


def test_form_degree_changes_series_and_hints(tmp_path, monkeypatch):
    at = _create(tmp_path, monkeypatch, "Omar", 9, "autism", severity="severe")
    import engine
    assert engine.get_settings("Omar")["severity"] == "severe"
    plan = next(m.value for m in at.markdown if "Today's plan" in m.value)
    assert "⬜ 3" in plan and "⬜ 4" not in plan                          # 3 questions per series
    _key(at, "soc_next").click().run()
    assert at.session_state["soc"]["level"] <= 2


def test_typical_profile_has_no_degree(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    at = AppTest.from_file(str(ROOT / "app.py"), default_timeout=60).run()
    at.radio(key="child_profile").set_value("typical").run()
    assert not any(r.key == "child_severity" for r in at.radio)
    at.radio(key="child_profile").set_value("adhd").run()
    assert any(r.key == "child_severity" for r in at.radio)


def test_autism_tools(tmp_path, monkeypatch):
    at = _create(tmp_path, monkeypatch, "Omar", 9, "autism", severity="moderate")
    assert [t.label for t in at.tabs][:3] == ["🌈 Feelings & routines", "🧰 My tools", "🧩 Puzzle & leaves"]
    _key(at, "day_done").click().run()                                       # My day: check off the first card
    import engine
    assert engine.kv_get("Omar", "day_plan")["done"] == [0]
    for tool in ["🎯 Emotion radar", "🗣️ Talk board", "🛒 Choice shop", "✅ My steps", "🎧 Sound studio",
                 "🌍 My interests"]:
        at.radio(key="tl_tool").set_value(tool).run()
        assert not at.exception, tool
    at.radio(key="tl_tool").set_value("🎯 Emotion radar").run()
    _key(at, "emo_🤷").click().run()                                          # "I don't know" is accepted
    assert any("I don't know" in x.value for x in at.success)
    at.radio(key="tl_tool").set_value("✅ My steps").run()
    n = len(at.session_state["steps"]["order"])
    for _ in range(n):
        _key(at, "st_ok").click().run()
    assert any("Finished" in x.value for x in at.success)
    assert "My steps" in set(engine.get_activities("Omar", "tools").category)
    _key(at, "qt_0").click().run()                                            # quick talk board in the sidebar
    assert any("Help me" in w.value for w in at.warning)


def test_dyslexia_build_and_read(tmp_path, monkeypatch):
    at = _create(tmp_path, monkeypatch, "Lina", 9, "dyslexia")
    assert "🧱 Build & read" in [t.label for t in at.tabs]
    b = at.session_state["bw"]                                                # build the word with the tiles
    for p in b["parts"][len(b["built"]):]:
        k = next(i for i, t in enumerate(at.session_state["bw"]["tiles"]) if t == p
                 and i not in at.session_state["bw"]["used"])
        _key(at, f"bw_t_{k}").click().run()
    _key(at, "bw_check").click().run()
    assert any("every letter helps" in x.value.lower() for x in at.success)
    at.radio(key="br_act").set_value("🧩 Sentence puzzle").run()
    for i in range(len(at.session_state["sp"]["cards"])):
        _key(at, f"sp_c_{i}").click().run()
    _key(at, "sp_check").click().run()
    assert any("right order" in x.value for x in at.success)
    at.radio(key="br_act").set_value("🔊 Magic echo").run()
    _key(at, "me_read").click().run()
    at.radio(key="br_act").set_value("📖 My story in pictures").run()
    for i in range(3):
        _key(at, f"ms_p_{i}").click().run()
    assert any("created a story" in x.value for x in at.success)
    import engine
    cats = set(engine.get_activities("Lina", "words").category)
    assert {"Build the word", "Sentence puzzle", "Magic echo", "My story"} <= cats
